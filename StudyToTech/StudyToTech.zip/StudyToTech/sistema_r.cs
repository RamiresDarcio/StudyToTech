using System;

namespace StudyToTech
{
    public class SistemaRecomendacao
    {
        public string Conteudo { get; set; }

        public string TipoRecomendacao { get; set; }

        public void CriarRecomendacao()
        {
            Console.WriteLine("\n===== RECOMENDAÇÃO =====");

            Console.WriteLine("Digite o conteúdo:");
            Conteudo = Console.ReadLine();

            Console.WriteLine("Digite o tipo:");
            TipoRecomendacao = Console.ReadLine();
        }

        public void MostrarRecomendacao()
        {
            Console.WriteLine("\n===== CONTEÚDO RECOMENDADO =====");

            Console.WriteLine("Conteúdo: " + Conteudo);

            Console.WriteLine("Tipo: " + TipoRecomendacao);
        }
    }
}