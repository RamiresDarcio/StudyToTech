using System;
using System.Collections.Generic;

namespace StudyToTech
{
    public class HistoricoAtividades
    {
        private List<string> atividades = new List<string>();

        public void AdicionarAtividade()
        {
            Console.WriteLine("\nDigite a atividade:");

            string atividade = Console.ReadLine();

            atividades.Add(atividade);

            Console.WriteLine("Atividade adicionada!");
        }

        public void MostrarHistorico()
        {
            Console.WriteLine("\n===== HISTÓRICO =====");

            foreach (string atividade in atividades)
            {
                Console.WriteLine("- " + atividade);
            }
        }
    }
}