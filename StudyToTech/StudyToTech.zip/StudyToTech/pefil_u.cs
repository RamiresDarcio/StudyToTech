using System;

namespace StudyToTech
{
    public class PerfilUsuario
    {
        public string NomeUsuario { get; set; }

        public string FotoPerfil { get; set; }

        public string DisciplinaFavorita { get; set; }

        public string MetaAtual { get; set; }

        public int TotalTrofeus { get; set; }

        public void CriarPerfil()
        {
            Console.WriteLine("\n===== PERFIL =====");

            Console.WriteLine("Digite o nome:");
            NomeUsuario = Console.ReadLine();

            Console.WriteLine("Digite a foto:");
            FotoPerfil = Console.ReadLine();

            Console.WriteLine("Digite a disciplina favorita:");
            DisciplinaFavorita = Console.ReadLine();

            Console.WriteLine("Digite a meta atual:");
            MetaAtual = Console.ReadLine();

            Console.WriteLine("Digite o total de troféus:");
            TotalTrofeus = int.Parse(Console.ReadLine());
        }

        public void ExibirPerfil()
        {
            Console.WriteLine("\n===== PERFIL =====");

            Console.WriteLine("Usuário: " + NomeUsuario);

            Console.WriteLine("Foto: " + FotoPerfil);

            Console.WriteLine("Disciplina favorita: " + DisciplinaFavorita);

            Console.WriteLine("Meta atual: " + MetaAtual);

            Console.WriteLine("Troféus: " + TotalTrofeus);
        }
    }
}