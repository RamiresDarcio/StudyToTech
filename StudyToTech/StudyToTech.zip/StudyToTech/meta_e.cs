using System;

namespace StudyToTech
{
    public class MetaEstudo
    {
        public string NomeMeta { get; set; }

        public int TempoMeta { get; set; }

        public int TempoConcluido { get; set; }

        public bool MetaConcluida { get; set; }

        public string Trofeu { get; set; }

        public void CriarMeta()
        {
            Console.WriteLine("\n===== META DE ESTUDO =====");

            Console.WriteLine("Digite o nome da meta:");
            NomeMeta = Console.ReadLine();

            Console.WriteLine("Digite o tempo da meta:");
            TempoMeta = int.Parse(Console.ReadLine());

            Console.WriteLine("Digite o tempo concluído:");
            TempoConcluido = int.Parse(Console.ReadLine());

            VerificarMeta();
        }

        public void VerificarMeta()
        {
            if (TempoConcluido >= TempoMeta)
            {
                MetaConcluida = true;

                Trofeu = "Troféu de Disciplina";

                Console.WriteLine("Meta concluída!");
            }
            else
            {
                MetaConcluida = false;

                Console.WriteLine("Meta não concluída.");
            }
        }

        public void ExibirMeta()
        {
            Console.WriteLine("\n===== STATUS DA META =====");

            Console.WriteLine("Meta: " + NomeMeta);

            Console.WriteLine("Tempo da meta: " + TempoMeta);

            Console.WriteLine("Tempo concluído: " + TempoConcluido);

            Console.WriteLine("Troféu: " + Trofeu);
        }
    }
}