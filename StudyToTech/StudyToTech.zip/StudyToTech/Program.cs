﻿using System;
using System.Collections.Generic;

namespace StudyToTech
{
    class Program
    {
        static void Main(string[] args)
        {
            Usuario usuario = null;
            gerenciamento_d gerDisc = new gerenciamento_d();
            gerenciamento_t_a gerTarefa = new gerenciamento_t_a();
            List<CalendarioEstudos> eventos = new List<CalendarioEstudos>();
            HistoricoAtividades historico = new HistoricoAtividades();
            PerfilUsuario perfil = null;
            MetaEstudo meta = null;
            DashboardEstudos dashboard = null;
            SistemaRecomendacao recomendacao = new SistemaRecomendacao();
            AnaliseDesempenho analise = new AnaliseDesempenho();

            while (true)
            {
                Console.WriteLine("\n=== Sistema de Gerenciamento de Estudos ===");
                Console.WriteLine("1. Cadastrar Usuário");
                Console.WriteLine("2. Criar Perfil");
                Console.WriteLine("3. Cadastrar Disciplina");
                Console.WriteLine("4. Listar Disciplinas");
                Console.WriteLine("5. Cadastrar Tarefa");
                Console.WriteLine("6. Listar Tarefas");
                Console.WriteLine("7. Criar Meta de Estudo");
                Console.WriteLine("8. Registrar Atividade no Dashboard");
                Console.WriteLine("9. Adicionar Evento ao Calendário");
                Console.WriteLine("10. Adicionar Atividade ao Histórico");
                Console.WriteLine("11. Mostrar Histórico");
                Console.WriteLine("12. Criar Recomendação");
                Console.WriteLine("13. Mostrar Análise de Desempenho");
                Console.WriteLine("14. Ver Perfil");
                Console.WriteLine("15. Ver Status da Meta");
                Console.WriteLine("16. Ver Resumo do Dashboard");
                Console.WriteLine("17. Sair");
                Console.Write("Escolha uma opção: ");
                string opcao = Console.ReadLine();

                switch (opcao)
                {
                    case "1":
                        usuario = new Usuario();
                        usuario.CadastrarUsuario();
                        break;
                    case "2":
                        if (usuario != null)
                        {
                            perfil = new PerfilUsuario();
                            perfil.CriarPerfil();
                        }
                        else
                        {
                            Console.WriteLine("Cadastre um usuário primeiro.");
                        }
                        break;
                    case "3":
                        disciplina d = new disciplina();
                        d.cadastrar_disciplina();
                        gerDisc.adicionar_disciplina(d);
                        break;
                    case "4":
                        gerDisc.listar_disciplinas();
                        break;
                    case "5":
                        gerTarefa.AdicionarTarefa();
                        break;
                    case "6":
                        gerTarefa.ListarTarefas();
                        break;
                    case "7":
                        if (usuario != null)
                        {
                            meta = new MetaEstudo();
                            meta.CriarMeta();
                        }
                        else
                        {
                            Console.WriteLine("Cadastre um usuário primeiro.");
                        }
                        break;
                    case "8":
                        if (usuario != null)
                        {
                            dashboard = new DashboardEstudos();
                            dashboard.RegistrarAtividade();
                        }
                        else
                        {
                            Console.WriteLine("Cadastre um usuário primeiro.");
                        }
                        break;
                    case "9":
                        CalendarioEstudos c = new CalendarioEstudos();
                        c.AdicionarEvento();
                        eventos.Add(c);
                        break;
                    case "10":
                        historico.AdicionarAtividade();
                        break;
                    case "11":
                        historico.MostrarHistorico();
                        break;
                    case "12":
                        recomendacao.CriarRecomendacao();
                        recomendacao.MostrarRecomendacao();
                        break;
                    case "13":
                        if (dashboard != null)
                        {
                            analise.HorasEstudadas = dashboard.TempoEstudo;
                            analise.TarefasConcluidas = gerTarefa.ObterTotalTarefas();
                            analise.MetasConcluidas = meta != null && meta.MetaConcluida ? 1 : 0;
                            analise.MostrarAnalise();
                        }
                        else
                        {
                            Console.WriteLine("Registre atividades no dashboard primeiro.");
                        }
                        break;
                    case "14":
                        if (perfil != null)
                        {
                            perfil.ExibirPerfil();
                        }
                        else
                        {
                            Console.WriteLine("Crie um perfil primeiro.");
                        }
                        break;
                    case "15":
                        if (meta != null)
                        {
                            meta.ExibirMeta();
                        }
                        else
                        {
                            Console.WriteLine("Crie uma meta primeiro.");
                        }
                        break;
                    case "16":
                        if (dashboard != null)
                        {
                            dashboard.ExibirResumo();
                        }
                        else
                        {
                            Console.WriteLine("Registre atividades no dashboard primeiro.");
                        }
                        break;
                    case "17":
                        return;
                    default:
                        Console.WriteLine("Opção inválida.");
                        break;
                }
            }
        }
    }
}
